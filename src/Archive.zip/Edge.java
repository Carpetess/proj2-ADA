/**
 * @author André Filipe 65371, Guilherme Fialho 65581
 */
public record Edge(int first, int second, int hardness) {}