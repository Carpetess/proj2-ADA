public record Node(int node, int cost) {
}
