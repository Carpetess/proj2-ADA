/**
 * @author André Filipe 65371, Guilherme Fialho 65581
 */
public record Node(int node, int cost) {
}
